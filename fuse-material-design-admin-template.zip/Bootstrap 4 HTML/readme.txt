**************************************
 Thank you for purchasing our template
**************************************

FILES
-----
Fuse-Bootstrap4-HTML-v1.2.4.zip :  Fuse Template (Bootstrap4 - HTML)


UPDATING THE TEMPLATE
---------------------
You can the GitHub repository to easily update the template.
To access the repository visit: http://withinpixels.com/themes/fuse-github


SUPPORT REQUESTS
----------------
For your support requests, please visit http://withinpixels.ticksy.com
Your support requests will be queued and can take up to 48 hours in
working days before answered.